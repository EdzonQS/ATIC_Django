$(document).ready(function() {
    $('.navburger').click(function() {
			$('nav').css("display", "block");
		});
	$('#close').click(function() {
			$('nav').css("display", "none");
		});
});
